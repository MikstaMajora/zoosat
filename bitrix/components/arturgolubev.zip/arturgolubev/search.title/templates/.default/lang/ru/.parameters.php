<?
$MESS["ARTURGOLUBEV_SMARTSEARCH_TEMPLATE_SHOW_PREVIEW_TEXT"] = "Показывать в результатах текст анонса";
$MESS["TP_BST_SHOW_INPUT"] = "Показывать форму ввода поискового запроса";
$MESS["TP_BST_PRICE_CODE"] = "Тип цены";
$MESS["TP_BST_SHOW_PREVIEW"] = "Показать картинку";
$MESS["TP_BST_SHOW_PROPS"] = "Отображать свойства товара (укажите id необходимых свойств)";
$MESS["TP_BST_PREVIEW_WIDTH"] = "Ширина картинки";
$MESS["TP_BST_PREVIEW_HEIGHT"] = "Высота картинки";
$MESS["TP_BST_PREVIEW_TRUNCATE_LEN"] = "Максимальная длина анонса для вывода";
$MESS["TP_BST_CONVERT_CURRENCY"] = "Показывать цены в одной валюте";
$MESS["TP_BST_CURRENCY_ID"] = "Валюта, в которую будут сконвертированы цены";
$MESS["TP_BST_PRICE_VAT_INCLUDE"] = "Включать НДС в цену";

$MESS["AG_TP_BST_INPUT_ID"] = "ID поля ввода поискового запроса (ID должен быть уникальным)";
$MESS["AG_TP_BST_CONTAINER_ID"] = "ID контейнера, по ширине которого будут выводиться результаты (ID должен быть уникальным)";

$MESS["TP_BST_SHOW_LOADING_ANIMATE"] = "Показывать анимацию загрузки";
$MESS["TP_BST_INPUT_PLACEHOLDER"] = "Текст в поле ввода поискового запроса (placeholder)";
$MESS["TP_BST_SHOW_HISTORY"] = "Показывать историю запросов";
?>