<?
$MESS["CT_BST_SEARCH_BUTTON"] = "Поиск";
$MESS["AG_SMARTIK_SECTION_TITLE"] = "Категория";
$MESS["AG_SMARTIK_NO_RESULT"] = "По вашему запросу ничего не найдено. Попробуйте уточнить запрос или ввести другой";
?>