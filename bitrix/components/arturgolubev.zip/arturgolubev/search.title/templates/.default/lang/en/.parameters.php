<?
$MESS["TP_BST_SHOW_INPUT"] = "Show Search Query Input Form";
$MESS["TP_BST_INPUT_ID"] = "Search Query Input Element ID";
$MESS["TP_BST_CONTAINER_ID"] = "Layout Container ID (to confine search results by width)";
$MESS["TP_BST_PRICE_CODE"] = "Price type";
$MESS["TP_BST_SHOW_PREVIEW"] = "Show image";
$MESS["TP_BST_PREVIEW_WIDTH"] = "Image width";
$MESS["TP_BST_PREVIEW_HEIGHT"] = "Image height";
$MESS["TP_BST_PREVIEW_TRUNCATE_LEN"] = "Maximum preview text length";
$MESS["TP_BST_CONVERT_CURRENCY"] = "Use only one currency to show prices";
$MESS["TP_BST_CURRENCY_ID"] = "Convert all prices to currency";
$MESS["TP_BST_PRICE_VAT_INCLUDE"] = "Include tax rate in price";
?>