<?
$MESS["CP_BST_FORM_PAGE"] = "Search results page (#SITE_DIR# macro is available)";
$MESS["CP_BST_NUM_CATEGORIES"] = "Number Of Search Categories";
$MESS["CP_BST_NUM_CATEGORY"] = "Category ##NUM#";
$MESS["CP_BST_CATEGORY_TITLE"] = "Category Name";
$MESS["CP_BST_TOP_COUNT"] = "Results Per Category";
$MESS["CP_BST_CHECK_DATES"] = "Search only in documents active on date of search";
$MESS["CP_BST_SHOW_OTHERS"] = "Show \"Misc.\" Category";
$MESS["CP_BST_OTHERS_CATEGORY"] = "Misc. Category";
$MESS["CP_BST_USE_LANGUAGE_GUESS"] = "Autodetect Keyboard Layout";
$MESS["CP_BST_ORDER"] = "Sort By";
$MESS["CP_BST_ORDER_BY_DATE"] = "date";
$MESS["CP_BST_ORDER_BY_RANK"] = "relevance";
?>