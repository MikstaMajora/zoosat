<?
$MESS["CD_BST_NAME"] = "Search Titles";
$MESS["CD_BST_DESCRIPTION"] = "Dynamic title search.";
$MESS["CD_BST_SEARCH"] = "Search";
?>