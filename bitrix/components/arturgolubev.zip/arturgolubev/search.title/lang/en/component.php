<?
$MESS["CC_BST_MODULE_NOT_INSTALLED"] = "Sorry, the search module is temporary unavailable.";
$MESS["CC_BST_ALL_RESULTS"] = "All Results";
$MESS["CC_BST_MORE"] = "more";
$MESS["CC_BST_QUERY_PROMPT"] = "results for: <b>\"#query#\"</b>";
$MESS["CC_BST_ALL_QUERY_PROMPT"] = "All results for: <b>\"#query#\"</b>";
?>