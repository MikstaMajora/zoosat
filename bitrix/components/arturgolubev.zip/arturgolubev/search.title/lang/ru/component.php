<?
$MESS['ARTURGOLUBEV_SMARTSEARCH_MODULE_UNAVAILABLE'] = "Демо-период решение <a href='http://marketplace.1c-bitrix.ru/solutions/arturgolubev.smartsearch/' target='_blank'>Умный поиск с исправлением ошибок в запросе и подсказками</a> закончился";

$MESS["CC_BST_MODULE_NOT_INSTALLED"] = "Модуль поиска не установлен.";
$MESS["CC_BST_ALL_RESULTS"] = "Все результаты";
$MESS["CC_BST_MORE"] = "остальные";
$MESS["CC_BST_QUERY_PROMPT"] = "результаты для: <b>\"#query#\"</b>";
$MESS["CC_BST_ALL_QUERY_PROMPT"] = "Все результаты для: <b>\"#query#\"</b>";
?>