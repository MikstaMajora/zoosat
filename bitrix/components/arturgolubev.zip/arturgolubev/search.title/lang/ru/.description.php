<?
$MESS["ARTUR_GOLUBEV_SMARTSEARCH_SEARCH_TITLE_COMPONENT_NAME"] = "Умный поиск по заголовкам";
$MESS["ARTUR_GOLUBEV_SMARTSEARCH_SEARCH_TITLE_DESCRIPTION"] = "Поиск по заголовком с динамическим выводом результата";
$MESS['ARTUR_GOLUBEV_SMARTSEARCH_SEARCH_TITLE_MAIN_FOLDER'] = "Компоненты от Артура Голубева";
$MESS['ARTUR_GOLUBEV_SMARTSEARCH_SEARCH_TITLE_FOLDER'] = "Умный поиск";
?>