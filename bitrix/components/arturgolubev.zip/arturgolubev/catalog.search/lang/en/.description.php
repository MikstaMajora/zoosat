<? 
$MESS["CD_BCSE_CATALOG"] = "Catalog";
$MESS["CD_BCSE_NAME"] = "Search catalog";
$MESS["CD_BCSE_DESCRIPTION"] = "Searches the catalog by properties, price etc. and shows search results.";
?>