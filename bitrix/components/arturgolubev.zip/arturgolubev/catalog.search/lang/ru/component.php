<? 
$MESS['ARTURGOLUBEV_SMARTSEARCH_MODULE_UNAVAILABLE'] = "Демо-период решение <a href='http://marketplace.1c-bitrix.ru/solutions/arturgolubev.smartsearch/' target='_blank'>Умный поиск с исправлением ошибок в запросе и подсказками</a> закончился";
?>