<? 
$MESS["ARTUR_GOLUBEV_SMARTSEARCH_CATLOG_SEARCH_COMPONENT_NAME"] = "Умный поиск по каталогу";
$MESS["ARTUR_GOLUBEV_SMARTSEARCH_CATLOG_SEARCH_DESCRIPTION"] = "Выводит результаты поиска по элементам каталога с указанным набором свойств, цен и т.д.";
$MESS['ARTUR_GOLUBEV_SMARTSEARCH_CATLOG_SEARCH_MAIN_FOLDER'] = "Компоненты от Артура Голубева";
$MESS['ARTUR_GOLUBEV_SMARTSEARCH_CATLOG_SEARCH_FOLDER'] = "Умный поиск";
?>