<?
$MESS["SEARCH_MODULE_UNAVAILABLE"] = "Sorry, the search module is temporary unavailable.";
$MESS["SEARCH_RESULTS"] = "Search results";
$MESS["SEARCH_FORUM"] = "Forum";
$MESS["SEARCH_BLOG"] = "Blogs";
$MESS["SEARCH_SOCIALNETWORK"] = "Social network";
$MESS["SEARCH_INTRANET"] = "Users";
$MESS["SEARCH_CRM"] = "CRM";
$MESS["SEARCH_DISK"] = "Drive files";
?>