<?
$MESS["SEARCH_WHERE_DROPDOWN"] = "Values for drop-down list \"Where to search\"";
$MESS["SEARCH_PAGE_RESULT_COUNT"] = "Results per page";
$MESS["SEARCH_SHOW_DROPDOWN"] = "Show drop-down list \"Where to search\"";
$MESS["SEARCH_CHECK_DATES"] = "Search only in documents active on date of search";
$MESS["SEARCH_RESTART"] = "Try to search without morphology support (if no search results found)";
$MESS["SEARCH_PAGER_SETTINGS"] = "Pager settings";
$MESS["SEARCH_PAGER_TITLE"] = "Search results name";
$MESS["SEARCH_RESULTS"] = "Search results";
$MESS["SEARCH_PAGER_SHOW_ALWAYS"] = "Always show the pager";
$MESS["SEARCH_PAGER_TEMPLATE"] = "Name of the pager template";
$MESS["SEARCH_USE_TITLE_RANK"] = "Respect titles when ranking search results";
$MESS["CP_SP_DEFAULT_SORT"] = "Default sorting";
$MESS["CP_SP_DEFAULT_SORT_RANK"] = "by relevance ";
$MESS["CP_SP_DEFAULT_SORT_DATE"] = "by date";
$MESS["CP_BSP_SHOW_WHEN"] = "Allow filtering by document date";
$MESS["CP_BSP_DISPLAY_TOP_PAGER"] = "Show Above Results";
$MESS["CP_BSP_DISPLAY_BOTTOM_PAGER"] = "Show Below Results";
$MESS["CP_BSP_FILTER_NAME"] = "Extra Filter";
$MESS["CP_BSP_USE_LANGUAGE_GUESS"] = "Autodetect Keyboard Layout";
$MESS["CP_BSP_NO_WORD_LOGIC"] = "Disable processing of common words as logical operators";
?>