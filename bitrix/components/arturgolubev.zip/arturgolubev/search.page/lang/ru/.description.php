<?
$MESS["ARTUR_GOLUBEV_SMARTSEARCH_SEARCH_PAGE_COMPONENT_NAME"] = "Умная страница поиска";
$MESS["ARTUR_GOLUBEV_SMARTSEARCH_SEARCH_PAGE_DESCRIPTION"] = "Страница с формой поиска и списком результатов поиска";
$MESS['ARTUR_GOLUBEV_SMARTSEARCH_SEARCH_PAGE_MAIN_FOLDER'] = "Компоненты от Артура Голубева";
$MESS['ARTUR_GOLUBEV_SMARTSEARCH_SEARCH_PAGE_FOLDER'] = "Умный поиск";
?>