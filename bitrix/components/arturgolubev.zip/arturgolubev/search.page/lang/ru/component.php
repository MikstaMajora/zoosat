<?
$MESS['ARTURGOLUBEV_SMARTSEARCH_MODULE_UNAVAILABLE'] = "Демо-период решение <a href='http://marketplace.1c-bitrix.ru/solutions/arturgolubev.smartsearch/' target='_blank'>Умный поиск с исправлением ошибок в запросе и подсказками</a> закончился";

$MESS ['SEARCH_MODULE_UNAVAILABLE'] = "Извините, но модуль поиска временно недоступен";
$MESS ['SEARCH_RESULTS'] = "Результаты поиска";
$MESS ['SEARCH_FORUM'] = "Форум";
$MESS ['SEARCH_BLOG'] = "Блоги";
$MESS ['SEARCH_SOCIALNETWORK'] = "Социальная сеть";
$MESS ['SEARCH_INTRANET'] = "Пользователи";
$MESS ["SEARCH_CRM"] = "CRM";
$MESS ["SEARCH_DISK"] = "Файлы диска";

$MESS ["SEARCH_HISTORY_TITLE"] = "История поиска: ";
?>
