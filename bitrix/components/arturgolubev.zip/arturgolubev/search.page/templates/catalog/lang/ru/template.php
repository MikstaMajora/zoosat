<?
$MESS["AG_SPAGE_CLARIFY_SECTION"] = "По запросу найдены разделы каталога";
$MESS["AG_SPAGE_CLARIFY_TITLE"] = "Возможно вы искали:";
$MESS["AG_SPAGE_CLARIFY_SECTION"] = "Уточните раздел поиска:";
$MESS["AG_SPAGE_CLARIFY_SECTION_ALL"] = "Все";

$MESS["SEARCH_GO"] = "Искать";
$MESS["CT_BSP_ADDITIONAL_PARAMS"] = "Дополнительные параметры поиска";
$MESS["CT_BSP_KEYBOARD_WARNING"] = "В запросе \"#query#\" восстановлена раскладка клавиатуры.";
?>