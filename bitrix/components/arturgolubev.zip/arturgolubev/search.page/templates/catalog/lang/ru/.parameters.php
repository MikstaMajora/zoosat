<?
$MESS["TP_BSP_INPUT_PLACEHOLDER"] = "Текст в поле ввода поискового запроса (placeholder)";
$MESS["CP_BSP_SHOW_HISTORY"] = "Показывать историю запросов";
?>