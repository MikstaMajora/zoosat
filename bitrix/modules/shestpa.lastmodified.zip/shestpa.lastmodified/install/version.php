<?
$arModuleVersion = array(
	"VERSION" => "0.1.0",
	"VERSION_DATE" => "2017-03-06 10:00:00"
);
?>