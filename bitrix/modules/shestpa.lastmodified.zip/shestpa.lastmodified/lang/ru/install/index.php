<?php
defined('B_PROLOG_INCLUDED') and (B_PROLOG_INCLUDED === true) or die();

$MESS['MODULE_NAME'] = 'Установка заголовка Last-Modified';
$MESS['MODULE_DESCRIPTION'] = 'Модуль для установки HTTP-заголовка Last-Modified на страницах сайта';
