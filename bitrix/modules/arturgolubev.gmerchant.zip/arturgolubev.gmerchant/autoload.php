<?
CModule::AddAutoloadClasses('arturgolubev.gmerchant', array(
	'Arturgolubev\Gmerchant\Encoding' => 'lib/encoding.php',
	'Arturgolubev\Gmerchant\Simplefilter' => 'lib/simplefilter.php',
	'Arturgolubev\Gmerchant\Settings' => 'lib/settings.php',
	'Arturgolubev\Gmerchant\Tools' => 'lib/tools.php',
	'Arturgolubev\Gmerchant\Ui' => 'lib/ui.php',
));