<?
$MESS["arturgolubev.gmerchant_MODULE_NAME"] = "Выгрузка каталога товаров в Google Merchant, TikTok, Facebook, Instagram";
$MESS["arturgolubev.gmerchant_MODULE_DESC"] = "Генерирует выгрузку товаров в формате .xml";
$MESS["arturgolubev.gmerchant_PARTNER_NAME"] = "Голубев Артур";
$MESS["arturgolubev.gmerchant_PARTNER_URI"] = "http://arturgolubev.ru";

$MESS["ARTURGOLUBEV_GMERCHANT_INSTALL_SUCCESS"] = "Установка модуля \"#MOD_NAME#\" успешно завершена";

$MESS["ARTURGOLUBEV_GMERCHANT_WHAT_DO"] = "Как действовать дальше?";
$MESS["ARTURGOLUBEV_GMERCHANT_WHAT_DO_TEXT"] = '
	<div>
		Подробная информация по созданию и настройке профиля выгрузки размещена на <a href="http://marketplace.1c-bitrix.ru/solutions/arturgolubev.gmerchant/#tab-install-link" target="_blank">вкладке установка в карточке решения</a>
		<br>
		<br>
		Создать новый профиль выгрузки вы можете на <a href="/bitrix/admin/cat_export_setup.php?lang=ru" target="_blank">странице настроек экспорта</a>
	</div>
';
$MESS["ARTURGOLUBEV_GMERCHANT_SALE_NOT_FOUND"] = "Не найден модуль sale или catalog. Проверьте вашу редакцию 1с-Битрикс: для работы решения требуется редакция с модулем Интернет-Магазин, т.е. Малый бизнес, Бизнес либо Интернет-Магазин + CRM";
?>