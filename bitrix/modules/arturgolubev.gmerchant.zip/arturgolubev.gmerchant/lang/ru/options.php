<?

/* help tab */
$MESS["ARTURGOLUBEV_GMERCHANT_HELP_TAB_NAME"] = "Информация";
$MESS["ARTURGOLUBEV_GMERCHANT_HELP_TAB_TITLE"] = "Полезная информация";

$MESS["ARTURGOLUBEV_GMERCHANT_USE_GMERCHANT"] = "Где создавать и настраивать профили выгрузки?";
$MESS["ARTURGOLUBEV_GMERCHANT_USE_GMERCHANT_VALUE"] = "<a href='/bitrix/admin/cat_export_setup.php?lang=ru' target='_blank'>В разделе \"Экспорт данных\"</a>";

$MESS["ARTURGOLUBEV_GMERCHANT_CARD_TEXT"] = "Карточка решения на Marketplace -";
$MESS["ARTURGOLUBEV_GMERCHANT_CARD_TEXT_VALUE"] = "<a href='https://marketplace.1c-bitrix.ru/solutions/arturgolubev.gmerchant/#tab-about-link' target='_blank'>открыть</a>";

$MESS["ARTURGOLUBEV_GMERCHANT_INSTALL_TEXT"] = "Информация по установке -";
$MESS["ARTURGOLUBEV_GMERCHANT_INSTALL_TEXT_VALUE"] = "<a href='https://marketplace.1c-bitrix.ru/solutions/arturgolubev.gmerchant/#tab-install-link' target='_blank'>открыть</a>";

$MESS["ARTURGOLUBEV_GMERCHANT_INSTALL_VIDEO_TEXT"] = "Видео-инструкция -";
$MESS["ARTURGOLUBEV_GMERCHANT_INSTALL_VIDEO_TEXT_VALUE"] = "<a href='http://arturgolubev.ru/knowledge/course2/' target='_blank'>открыть</a>";

$MESS["ARTURGOLUBEV_GMERCHANT_FAQ_TEXT"] = "Часто задаваемые вопросы по данному модулю -";
$MESS["ARTURGOLUBEV_GMERCHANT_FAQ_TEXT_VALUE"] = "<a href='http://arturgolubev.ru/knowledge/course2/' target='_blank'>открыть</a>";

$MESS["ARTURGOLUBEV_GMERCHANT_FAQ_MAIN_TEXT"] = "Вопросы по покупке, оплате, активации модуля и т.п. -";
$MESS["ARTURGOLUBEV_GMERCHANT_FAQ_MAIN_TEXT_VALUE"] = "<a href='http://arturgolubev.ru/knowledge/course1/' target='_blank'>открыть</a>";

/* event messages */

$MESS["ARTURGOLUBEV_GMERCHANT_DEMO_IS_EXPIRED"] = "Демонстрационный период работы решения закончился. Для дальнейшего использования необходимо приобрести полую версию решения в <a href=\"http://marketplace.1c-bitrix.ru/solutions/arturgolubev.gmerchant/\" target=\"_blank\">marketplace.1c-bitrix.ru</a>";
$MESS["ARTURGOLUBEV_GMERCHANT_SALE_NOT_FOUND"] = "Не найден модуль sale или catalog. Проверьте вашу редакцию 1с-Битрикс: для работы решения требуется редакция с модулем Интернет-Магазин, т.е. Малый бизнес, Бизнес либо Интернет-Магазин + CRM";
?>