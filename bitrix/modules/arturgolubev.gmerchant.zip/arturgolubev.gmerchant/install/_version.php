<?
$arModuleVersion = array(
	"VERSION" => "2.1.5",
	"VERSION_DATE" => "2020-09-23 16:37:52"
);
?>