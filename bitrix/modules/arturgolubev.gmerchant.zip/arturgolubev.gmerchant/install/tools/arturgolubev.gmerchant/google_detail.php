<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/arturgolubev.gmerchant/load/googlemerchant_detail.php");
?>