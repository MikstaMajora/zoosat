<?
$MESS['ARTURGOLUBEV_WATCHER_TABLE_COLUMN_NAME'] = 'Решение';
$MESS['ARTURGOLUBEV_WATCHER_TABLE_COLUMN_ACTION'] = 'Обновления и поддержка';
$MESS['ARTURGOLUBEV_WATCHER_FULL_MODULE_LIST_HREF'] = '<a href="/bitrix/admin/partner_modules.php?lang=ru">Смотреть список всех решений и подробную информацию о них</a>';

$MESS['ARTURGOLUBEV_WATCHER_EMPTY_EVENTS'] = 'Важных оповещений не обнаружено.<br><br><a href="/bitrix/admin/partner_modules.php?lang=ru">Смотреть список всех решений и подробную информацию о них</a>';

$MESS['ARTURGOLUBEV_WATCHER_MOD_UPDATE_END'] = 'Закончились ';
$MESS['ARTURGOLUBEV_WATCHER_MOD_UPDATE_BUY'] = 'Купить продление';
$MESS['ARTURGOLUBEV_WATCHER_MOD_HAVE_UPDATE'] = 'Доступны обновления';
$MESS['ARTURGOLUBEV_WATCHER_MOD_HAVE_UPDATE_NOINSTALL'] = 'Вышли новые обновления!';

$MESS['ARTURGOLUBEV_WATCHER_MOD_NEW_BUY'] = 'Купить полную версию';
$MESS['ARTURGOLUBEV_WATCHER_DEMO_TIME_OUT'] = 'Работает в демо-режиме до ';

$MESS['ARTURGOLUBEV_WATCHER_DB_ERROR'] = 'Ошибка запроса к базе данных виджета';

$MESS['ARTURGOLUBEV_WATCHER_WARNING_DEMO_NOW'] = 'Решения в демонстрационном режиме:';
$MESS['ARTURGOLUBEV_WATCHER_WARNING_DEMO_END'] = 'Закончился срок действия демо-режима:';
$MESS['ARTURGOLUBEV_WATCHER_WARNING_UPDATE_END'] = 'Закончился период обновлений и технической поддержки решений:';
$MESS['ARTURGOLUBEV_WATCHER_WARNING_HAVE_UPDATES'] = 'Вышли новые обновления:';
$MESS['ARTURGOLUBEV_WATCHER_WARNING_ALL_OKEY'] = 'Всё ок:';


$MESS['ARTURGOLUBEV_WATCHER_EVENT_SEND_TITLE'] = 'Почтовая система';
$MESS['ARTURGOLUBEV_WATCHER_SUBSCRIBE_TITLE'] = 'Модуль рассылки';

$MESS['ARTURGOLUBEV_WATCHER_MESSAGES_WAIT'] = 'Ожидают обработки';
$MESS['ARTURGOLUBEV_WATCHER_MESSAGES_ERRORS'] = 'Ошибка при попытке отправки';
$MESS['ARTURGOLUBEV_WATCHER_MESSAGES_SUCCESS'] = 'Успешно отправлено';
$MESS['ARTURGOLUBEV_WATCHER_MESSAGES_UNKNOWN'] = 'Не определено';

$MESS['ARTURGOLUBEV_WATCHER_HREF_TO_TABLE'] = '(смотреть таблицу)';

$MESS['ARTURGOLUBEV_WATCHER_CHECK_DATE'] = 'Проверено #checkdate# (обновляется каждый час)';
?>