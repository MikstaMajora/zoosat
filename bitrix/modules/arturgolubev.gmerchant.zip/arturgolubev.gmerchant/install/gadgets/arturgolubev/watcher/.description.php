<?
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();
$arDescription = Array(
	'NAME' => GetMessage('ARTURGOLUBEV_WATCHER_GADGET_NAME'),
	'DESCRIPTION' => GetMessage('ARTURGOLUBEV_WATCHER_GADGET_DESC'),
	'ICON' => '',
	'TITLE_ICON_CLASS' => 'ag-statemail-gadgeticon',
	'GROUP' => array('ID' => 'other'),
	// 'NOPARAMS' => 'Y',
	'AI_ONLY' => true,
	'SECURITY_ONLY' => true,
	// 'COLOURFUL' => true
);
?>