<?
$MESS['ARTURGOLUBEV_WATCHER_PARAM_SHOW_TARGET'] = "Область сканирования (v.2.0)";
$MESS['ARTURGOLUBEV_WATCHER_PARAM_SHOW_TARGET_AG'] = "Решения разработчика arturgolubev";
$MESS['ARTURGOLUBEV_WATCHER_PARAM_SHOW_TARGET_ALL'] = "Все решения";
?>