<?
$MESS['ARTURGOLUBEV_WATCHER_GADGET_NAME'] = "Marketplace Watcher";
$MESS['ARTURGOLUBEV_WATCHER_GADGET_DESC'] = "Отслеживает и информирует о демо-периоде, окончании срока обновлений готовых решений";
?>