<?
$arModuleVersion = array(
	"VERSION" => "2.7.5",
	"VERSION_DATE" => "2022-10-15 11:01:00"
);
?>