
; /* Start:"a:4:{s:4:"full";s:91:"/bitrix/templates/aspro_next/components/bitrix/main.profile/profile/script.js?1617600574120";s:6:"source";s:77:"/bitrix/templates/aspro_next/components/bitrix/main.profile/profile/script.js";s:3:"min";s:0:"";s:3:"map";s:0:"";}"*/
$(document).ready(function(){
	$('a.cancel').click(function(e){
		e.preventDefault()
		document.form1.reset();
	});
});

/* End */
;; /* /bitrix/templates/aspro_next/components/bitrix/main.profile/profile/script.js?1617600574120*/
