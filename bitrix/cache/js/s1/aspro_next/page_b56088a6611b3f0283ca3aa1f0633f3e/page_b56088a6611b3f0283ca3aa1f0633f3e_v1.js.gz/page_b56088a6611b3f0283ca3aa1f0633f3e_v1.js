
; /* Start:"a:4:{s:4:"full";s:94:"/bitrix/templates/aspro_next/components/bitrix/catalog/new_manufacturers/script.js?16225188912";s:6:"source";s:82:"/bitrix/templates/aspro_next/components/bitrix/catalog/new_manufacturers/script.js";s:3:"min";s:0:"";s:3:"map";s:0:"";}"*/


/* End */
;; /* /bitrix/templates/aspro_next/components/bitrix/catalog/new_manufacturers/script.js?16225188912*/
